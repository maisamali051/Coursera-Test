/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author Maisam's PC
 */
public class HotelManagement extends JFrame implements ActionListener{
    JButton admin,user;
    HotelManagement(){
        setBounds(0,0,1800,920);//set location and length, breadth of the frame
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//to close the frame on close button
        setBackground(Color.white);//to set background to white
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/first.jpg"));
        Image img=i1.getImage().getScaledInstance(1800, 920, Image.SCALE_DEFAULT);
        ImageIcon img2=new ImageIcon(img);
        JLabel image=new JLabel(img2);
        image.setBounds(0,0,1800,920);
        
        add(image);
        JLabel text=new JLabel("Hotel Management System");
        text.setBounds(400,100,700,55);
        text.setForeground(Color.white);
        text.setFont(new Font("serif",Font.PLAIN,50));
        image.add(text);
        
        admin = new JButton("Admin");
         admin.setBounds(30,20,200,34);
         admin.setBackground(Color.black);
        admin.setForeground(Color.white);
        admin.setFont(new Font("serif",Font.PLAIN,26));
        admin.addActionListener(this);
        image.add(admin);
        
        user = new JButton("User");
         user.setBounds(250,20,200,34);
         user.setBackground(Color.black);
        user.setForeground(Color.white);
        user.setFont(new Font("serif",Font.PLAIN,26));
        user.addActionListener(this);
        image.add(user);
        
        setVisible(true);//visibility is by default false
        
         while(true){
           text.setVisible(false);
       try{   Thread.sleep(500);
       } catch (Exception e){
              e.printStackTrace();
            }
       text.setVisible(true);
       try{  Thread.sleep(500);
       } catch (Exception e){
              e.printStackTrace();
            }
       }
    }
     public void actionPerformed(ActionEvent ae){
        new Login();
      }
    public static void main(String[] args) {
    new HotelManagement();
    }
}