/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.DbUtils; // Ensure this library is added to your project

public class SearchRoom extends JFrame implements ActionListener {
    JTable table;
    JButton back;
    JButton Submit;
    JComboBox<String> bedType;
    JCheckBox available;

    public SearchRoom() {
        getContentPane().setBackground(Color.white);
        setLayout(null);

        JLabel text = new JLabel("Search for Room");
        text.setFont(new Font("Tahoma", Font.PLAIN, 20));
        text.setBounds(400, 30, 200, 30);
        add(text);

        JLabel lblBed = new JLabel("Bed Type");
        lblBed.setBounds(150, 100, 100, 20);
        add(lblBed);

        bedType = new JComboBox<>(new String[] { "Single", "Double","Suite" });
        bedType.setBounds(250, 100, 150, 25);
        bedType.setBackground(Color.WHITE);
        add(bedType);

        available = new JCheckBox("Only Display Available");
        available.setBounds(450, 100, 200, 25);
        available.setBackground(Color.WHITE);
        add(available);

        JLabel l1 = new JLabel("Room Number");
        l1.setBounds(50, 160, 100, 20);
        add(l1);

        JLabel l2 = new JLabel("Availability");
        l2.setBounds(270, 160, 100, 20);
        add(l2);

        JLabel l3 = new JLabel("Cleaning Status");
        l3.setBounds(450, 160, 100, 20);
        add(l3);

        JLabel l4 = new JLabel("Price");
        l4.setBounds(670, 160, 100, 20);
        add(l4);

        JLabel l5 = new JLabel("Bed Type");
        l5.setBounds(870, 160, 100, 20);
        add(l5);

        table = new JTable();
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(50, 200, 900, 300);
        add(sp);

        // Fetch and display room data in the table
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM room");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }

         Submit = new JButton("Submit");
        Submit.setBackground(Color.black);
        Submit.setForeground(Color.white);
        Submit.addActionListener(this);
        Submit.setBounds(500, 520, 120, 30);
        add(Submit);
        
        back = new JButton("Back");
        back.setBackground(Color.black);
        back.setForeground(Color.white);
        back.addActionListener(this);
        back.setBounds(400, 520, 120, 30);
        add(back);

        setBounds(200, 85, 1000, 600);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==Submit){
            try{
                String query1="Select * from room where bed_type = '"+bedType.getSelectedItem()+"'";
                String query2="Select * from room where Availability ='Available' and bed_type= '"+bedType.getSelectedItem()+"'";
                        Conn conn=new Conn();
                        ResultSet rs;
                        if(available.isSelected()){
                            rs=conn.s.executeQuery(query2);
                        }else{
                           rs= conn.s.executeQuery(query1);
                        }
                          table.setModel(DbUtils.resultSetToTableModel(rs));
                        
        } catch (Exception e){
            e.printStackTrace();
        }
}
            else{
        setVisible(false);
        new Reception();
        }
    
        // Uncomment and implement the following line if Reception is another screen
        // new Reception();
             
    }


    public static void main(String[] args) {
        new SearchRoom();
    }
}