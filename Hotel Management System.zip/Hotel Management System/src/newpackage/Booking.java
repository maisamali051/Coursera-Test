/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.util.Date;
import javax.swing.*;
import java.awt.event.*;

public class Booking extends JFrame implements ActionListener{
    JLabel number, name, lblroomType,country,roomnumber,deposit,checkin,checkintime;
    JTextField tfnumber, tfname,tfcountry,tfdeposit;
    Choice croomnumber;
    JButton addCustomer,back;
    JComboBox<String> genderCombo,roomType;
     Booking(){
        getContentPane().setBackground(Color.white);
        
        setLayout(null);
        JLabel lblcustomer=new JLabel("New Customer Form");
        lblcustomer.setBounds(100,30,230,30);
        lblcustomer.setForeground(Color.blue);
        lblcustomer.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(lblcustomer);
        
         ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/fifth.png"));
        Image i2=i1.getImage().getScaledInstance(400, 440, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);        
        JLabel image=new JLabel(i3);
        image.setBounds(280,50,400,440);
        add(image);
        
        
        number=new JLabel("Number");
        number.setBounds(30,90,100,25);
        add(number);        
        tfnumber=new JTextField();
        tfnumber.setBounds(134,90,140,25);
        add(tfnumber);
        
         name=new JLabel("Name");
        name.setBounds(30,140,100,25);
        add(name);        
        tfname=new JTextField();
        tfname.setBounds(134,140,140,25);
        add(tfname);
        
        // Gender
        JLabel lblgender = new JLabel("Gender");
        lblgender.setBounds(30, 190, 100, 25);
        add(lblgender);

        String[] genderOptions = { "Male", "Female","null" };
        genderCombo = new JComboBox<>(genderOptions);
        genderCombo.setBounds(134, 190, 140, 25);
        genderCombo.setBackground(Color.WHITE);
        add(genderCombo);
        
        //Room type
         lblroomType=new JLabel("Room Type");
        lblroomType.setBounds(30,240,100,25);
        add(lblroomType);
        String[] rtype={"single","double","suite"};
        roomType=new JComboBox<>(rtype);
        roomType.setBounds(134,240,140,25);
        add(roomType);
        
       roomnumber=new JLabel("Room number");
        roomnumber.setBounds(30,290,100,25);
        add(roomnumber);        
        croomnumber=new Choice();
        croomnumber.setBounds(134,290,140,25);
        add(croomnumber);
        
        roomType.addActionListener(new ActionListener()
        {
            @Override 
        public void actionPerformed(ActionEvent e) {
            fetchRoomNumbers(); 
        }
        }
        );
               // roomType.addActionListener(e -> fetchRoomNumbers());

        country=new JLabel("Country");
        country.setBounds(30,340,100,25);
        add(country);        
        tfcountry=new JTextField();
        tfcountry.setBounds(134,340,140,25);
        add(tfcountry);         
      
         
        deposit=new JLabel("Deposit");
        deposit.setBounds(30,390,100,25);
        add(deposit);        
        tfdeposit=new JTextField();
        tfdeposit.setBounds(134,390,140,25);
        add(tfdeposit);
        
        checkin=new JLabel("Checkin time");
       checkin.setBounds(30,430,100,30);
        add(checkin);
        Date date =new Date();
        checkintime=new JLabel(""+date);
        checkintime.setBounds(134,430,175,30);
        add(checkintime);
       
        //Buttons
        addCustomer=new JButton("Book Room");
        addCustomer.setBackground(Color.black);
        addCustomer.setForeground(Color.white);
        addCustomer.setBounds(30,490,150,25);
        addCustomer.addActionListener(this);
        add(addCustomer);
        
        back=new JButton("Back");
        back.setBackground(Color.black);
        back.setForeground(Color.white);
        back.setBounds(200,490,100,25);
        back.addActionListener(this);
        add(back);
        
        setBounds(150,60,700,600);
        setVisible(true);
    }
    
    private void fetchRoomNumbers() {
        croomnumber.removeAll(); 
        String selectedRoomType = (String) roomType.getSelectedItem(); 
        try { 
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM room WHERE availability = 'available' AND bed_type ='" + selectedRoomType + "'");
            while (rs.next()) 
            { 
                croomnumber.add(rs.getString("room_number")); 
            }
        } catch (Exception e) { 
            e.printStackTrace();
        }
    }
    
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==addCustomer){
    String NUMBER=tfnumber.getText();
      String NAME=tfname.getText();
        String GENDER=(String)genderCombo.getSelectedItem();
          String COUNTRY=tfcountry.getText();
            String ROOM_TYPE=(String)roomType.getSelectedItem();
             String  ROOM_NO =croomnumber.getSelectedItem();
             String DEPOSIT = tfdeposit.getText();
            String CHECKIN_TIME=checkintime.getText();
             if(NAME.equals("")){
                 JOptionPane.showMessageDialog(null,"Name shouldnot be empty");
                 return;
             }
                       
            try {
    Conn conn = new Conn(); // Assuming 'Conn' is your database connection class
    String query = "INSERT INTO customer (number,name, gender, country,  room_no, deposit, checkin_time) "
                 + "VALUES ('" + NUMBER + "', '" + NAME + "', '" + GENDER + "', '" + COUNTRY + "', '" 
                   + ROOM_NO + "', '" + DEPOSIT + "', '" + CHECKIN_TIME + "')";
    String query2="update room set availability = 'occupied' where room_number = '"+ROOM_NO+"'";
    conn.s.executeUpdate(query); // Execute the query
     conn.s.executeUpdate(query2);
   JOptionPane.showMessageDialog(null,"Room booked successfully");
    setVisible(false);
   
} catch (Exception e) {
    e.printStackTrace();
     }
  }
        else if(ae.getSource()==back){
           setVisible(false);
        }
   }
   
    public static void main(String[] args) {
        new Booking();
    }
}