/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Date;
import java.awt.event.*;
/**
 *
 * @author Maisam's PC
 */
public class Checkout extends JFrame implements ActionListener{
    Choice ccustomer;
    JLabel  lblroom, lblroomNumber, lblCheckin,lblCheckintime,lblCheckout,lblCheckouttime;
    JButton checkout, back;
    public Checkout(){
        getContentPane().setBackground(Color.white);
        setLayout(null);
        
        JLabel text=new JLabel("Checkout");
        text.setBounds(100,20,100,30);
        text.setForeground(Color.blue);
        text.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(text);
        
        JLabel lblid=new JLabel("Customer ID");
        lblid.setBounds(30,80,100,30);
        add(lblid);
        
        ccustomer=new Choice();
        ccustomer.setBounds(150,85,150,25);
        add(ccustomer);
        
         
        lblroom=new JLabel("Room Number");
        lblroom.setBounds(30,130,100,30);
        add(lblroom);

        lblroomNumber=new JLabel();
        lblroomNumber.setBounds(150,130,100,30);
        add(lblroomNumber);
        
        lblCheckin=new JLabel("Checkin");
        lblCheckin.setBounds(30,180,100,30);
        add(lblCheckin);
        
        lblCheckintime=new JLabel();
        lblCheckintime.setBounds(150,180,100,30);
        add(lblCheckintime);
        
        
        try{
            Conn c = new Conn();
            ResultSet rs =c.s.executeQuery("select * from customer");
            while(rs.next()){
                ccustomer.add(rs.getString("number"));
                lblroomNumber.setText(rs.getString("room_no"));
                lblCheckintime.setText(rs.getString("checkin_time"));
            }
                
            
        }catch (Exception e){
            e.printStackTrace();
        }
        
         ccustomer.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                try {
                    Conn c = new Conn();
                    String selectedCustomer = ccustomer.getSelectedItem();
                    ResultSet rs = c.s.executeQuery("select * from customer where number = '" + selectedCustomer + "'");
                    if (rs.next()) {
                        lblroomNumber.setText(rs.getString("room_no"));
                        lblCheckintime.setText(rs.getString("checkin_time"));
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/tick.png"));
        Image i2=i1.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);        
        JLabel tick=new JLabel(i3);
        tick.setBounds(304,85,20,20);
        add(tick);
       
         lblCheckout=new JLabel("Checkout");
        lblCheckout.setBounds(30,230,100,30);
        add(lblCheckout);
        Date date =new Date();
        lblCheckouttime=new JLabel(""+date);
        lblCheckouttime.setBounds(150,230,175,30);
        add(lblCheckouttime);
        
        checkout=new JButton("Checkout");
        checkout.setBackground(Color.black);
        checkout.setForeground(Color.white);
        checkout.setBounds(30,280,120,30);
        checkout.addActionListener(this);
        add(checkout);
        
         back=new JButton("Back");
        back.setBackground(Color.black);
        back.setForeground(Color.white);
        back.setBounds(170,280,120,30);
        back.addActionListener(this);
        add(back);
        
        ImageIcon i4=new ImageIcon(ClassLoader.getSystemResource("icons/sixth.jpg"));
        Image i5=i4.getImage().getScaledInstance(400, 250, Image.SCALE_DEFAULT);
        ImageIcon i6=new ImageIcon(i5);        
        JLabel image=new JLabel(i6);
        image.setBounds(350,50,400,250);
        add(image);
        
        setBounds(300,200,800,400);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==checkout){
        String query1="delete from customer where number = '"+ccustomer.getSelectedItem()+"'";
        String query2="update room set availability = 'available' where room_number = '"+lblroomNumber.getText()+"'";
        
        try{
            Conn c=new Conn();
            c.s.executeUpdate(query1);
            c.s.executeUpdate(query2);
            JOptionPane.showMessageDialog(null, "checkout done");
            setVisible(false);
            new Reception();
        }catch(Exception e){
            
        }
        
        }else{
            setVisible(false);
            new Reception();
        }
    }
   
    public static void main(String[] args) {
        new Checkout();
    }
}
