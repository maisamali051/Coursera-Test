/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;

/**
 *
 * @author Maisam's PC
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Driver extends JFrame implements ActionListener {
    JButton add, cancel;
    JTextField tfname, tfcompany, tfmodel, tflocation, tfage;
    JComboBox<String> availableCombo, genderCombo;

    Driver() {
        // Set background color and layout
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        // Heading
        JLabel heading = new JLabel("ADD DRIVERS");
        heading.setFont(new Font("Tahoma", Font.BOLD, 18));
        heading.setBounds(150, 10, 220, 20);
        add(heading);

        // Name
        JLabel lblname = new JLabel("Name");
        lblname.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblname.setBounds(60, 80, 120, 30);
        add(lblname);

        tfname = new JTextField();
        tfname.setBounds(200, 80, 150, 30);
        add(tfname);

        // Age
        JLabel lblage = new JLabel("Age");
        lblage.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblage.setBounds(60, 120, 120, 30);
        add(lblage);

        tfage = new JTextField();
        tfage.setBounds(200, 120, 150, 30);
        add(tfage);

        // Gender
        JLabel lblgender = new JLabel("Gender");
        lblgender.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblgender.setBounds(60, 160, 120, 30);
        add(lblgender);

        String[] genderOptions = { "Male", "Female" };
        genderCombo = new JComboBox<>(genderOptions);
        genderCombo.setBounds(200, 160, 150, 30);
        genderCombo.setBackground(Color.WHITE);
        add(genderCombo);

        // Car Company
        JLabel lblcompany = new JLabel("Car Company");
        lblcompany.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblcompany.setBounds(60, 200, 120, 30);
        add(lblcompany);

        tfcompany = new JTextField();
        tfcompany.setBounds(200, 200, 150, 30);
        add(tfcompany);

        // Car Model
        JLabel lblmodel = new JLabel("Car Model");
        lblmodel.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblmodel.setBounds(60, 240, 120, 30);
        add(lblmodel);

        tfmodel = new JTextField();
        tfmodel.setBounds(200, 240, 150, 30);
        add(tfmodel);

        // Availability
        JLabel lblavailable = new JLabel("Available");
        lblavailable.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblavailable.setBounds(60, 280, 120, 30);
        add(lblavailable);

        String[] availableOptions = { "Available", "Busy" };
        availableCombo = new JComboBox<>(availableOptions);
        availableCombo.setBounds(200, 280, 150, 30);
        availableCombo.setBackground(Color.WHITE);
        add(availableCombo);

        // Location
        JLabel lbllocation = new JLabel("Location");
        lbllocation.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lbllocation.setBounds(60, 320, 120, 30);
        add(lbllocation);

        tflocation = new JTextField();
        tflocation.setBounds(200, 320, 150, 30);
        add(tflocation);

        // Add Driver Button
        add = new JButton("Add Driver");
        add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        add.setBounds(60, 370, 130, 30);
        add.addActionListener(this);
        add(add);

        // Cancel Button
        cancel = new JButton("Cancel");
        cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.WHITE);
        cancel.setBounds(220, 370, 130, 30);
        cancel.addActionListener(this);
        add(cancel);

        // Add Image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/eleven.jpg"));
        Image i2 = i1.getImage().getScaledInstance(500, 300, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(400, 30, 500, 300);
        add(image);

        // Frame settings
        setBounds(300, 200, 980, 470);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == add) {
            // Get field values
            String name = tfname.getText();
            String age = tfage.getText();
            String gender = (String) genderCombo.getSelectedItem();
            String company = tfcompany.getText();
            String model = tfmodel.getText();
            String available = (String) availableCombo.getSelectedItem();
            String location = tflocation.getText();

            // Validate inputs
            if (name.isEmpty() || age.isEmpty() || company.isEmpty() || model.isEmpty() || location.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields must be filled out.");
                return;
            }

            try {
                Conn c = new Conn();
                String str = "INSERT INTO driver VALUES('" + name + "', '" + age + "', '" + gender + "', '" +
                        company + "', '" + model + "', '" + available + "', '" + location + "')";
                c.s.execute(str);
                JOptionPane.showMessageDialog(null, "New Driver added successfully.");
                setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == cancel) {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Driver();
    }
}
