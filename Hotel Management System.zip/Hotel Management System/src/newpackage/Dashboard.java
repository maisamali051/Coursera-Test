/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author Maisam's PC
 */
public class Dashboard extends JFrame implements ActionListener{
    JMenuBar mb;
    JMenu logout;
    JMenuItem itemLogout;
     
        
        
    Dashboard(){
        setBounds(0,0,1550,1000);
        setLayout(null);
        ImageIcon icon1=new ImageIcon(ClassLoader.getSystemResource("icons/third.jpg"));
        Image icon2=icon1.getImage().getScaledInstance(1550, 1000, Image.SCALE_DEFAULT);
        ImageIcon icon3=new ImageIcon(icon2);
                
        JLabel image=new JLabel(icon3);
        image.setBounds(0,0,1550,1000);
        add(image);
        
        JLabel text=new JLabel("WELCOME TO HOTEL METROPOLE" );
                
        text.setBounds(300,80,1000,60);
        text.setFont(new Font("Tahoma",Font.PLAIN,45));
        text.setForeground(Color.white);
        image.add(text);
        
        mb=new JMenuBar();
        mb.setBounds(0,0,1566,30);
        image.add(mb);
        
        logout=new JMenu("Logout");
        logout.setForeground(Color.blue);
        mb.add(logout);
        
        itemLogout =new JMenuItem("Logout");
        itemLogout.setForeground(Color.red);
        itemLogout.addActionListener(this);
        logout.add(itemLogout);
        
       
        JMenu hotel=new JMenu("HOTEL MANAGEMENT");
        hotel.setForeground(Color.red);
        mb.add(hotel);
        JMenuItem reception=new JMenuItem("RECEPTION");
        reception.addActionListener(this);
        hotel.add(reception);
        
         JMenu admin=new JMenu("ADMIN");
        admin.setForeground(Color.blue);
        mb.add(admin);
        JMenuItem addEmployee=new JMenuItem("ADD EMPLOYEE");
        addEmployee.addActionListener(this);
        admin.add(addEmployee);
        JMenuItem addRooms=new JMenuItem("ADD ROOM");
        addRooms.addActionListener(this);
        admin.add(addRooms);
        JMenuItem addDriver=new JMenuItem("ADD DRIVER");
        addDriver.addActionListener(this);
        admin.add(addDriver);
        
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==itemLogout){
            setVisible(false);
        }else if(ae.getActionCommand().equals("ADD EMPLOYEE")){
           new AddEmployee();
        }else if(ae.getActionCommand().equals("ADD ROOM")){
            new AddRoom();
        }else if(ae.getActionCommand().equals("ADD DRIVER")){
            new Driver();
        }else if(ae.getActionCommand().equals("RECEPTION")){
            new Reception();
        }
    }
    public static void main(String[] args) {
       new Dashboard();  
    }
}