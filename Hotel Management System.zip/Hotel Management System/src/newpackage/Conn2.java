/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Maisam's PC
 */
public class Conn2{
    Connection c;
    Statement s;
    Conn2(){
    try{
        //step 1: registering the necessary driver
         Class.forName("com.mysql.cj.jdbc.Driver");//1st step to register the drivers
        //step 2: creating connection
         c=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management_system","newuser","root");  
        //step 3: creating statement
        s=c.createStatement();
    }
    catch (ClassNotFoundException | SQLException e){
    }
}
}