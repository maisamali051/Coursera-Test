/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;

/**
 *
 * @author Maisam's PC
 */
import javax.swing.*;
import java.awt.*;
import java.awt. event.*;
import java.sql.*;

public class AddRoom extends JFrame implements ActionListener{
    JButton add,cancel;
    JTextField tfroom,tfprice;
    JComboBox availableCombo,cleanCombo,typeCombo;
    
    AddRoom() {
        // Set background color
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel Heading= new JLabel("ADD ROOMS");
        Heading.setFont(new Font("Tahoma", Font.BOLD, 18));
        Heading.setBounds(150, 20, 220, 20);
        add(Heading); 
        
        JLabel lblroom= new JLabel("Room Number");
        lblroom.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblroom.setBounds(60, 80, 120, 30);
        add(lblroom);
        
        tfroom = new JTextField();
        tfroom.setBounds(200, 80, 150, 30);
        add(tfroom);
        
        JLabel lblavailable= new JLabel("Avaliable");
        lblavailable.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblavailable.setBounds(60, 130, 120, 30);
        add(lblavailable);
        
        String availableOptions[]={"Avaliable","Occupied"};
        availableCombo=new JComboBox(availableOptions);
        availableCombo.setBounds(200,130,150,30);
        availableCombo.setBackground(Color.WHITE);
        add(availableCombo);
        
         JLabel lblclean= new JLabel("Clean Status");
        lblclean.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblclean.setBounds(60, 180, 120, 30);
        add(lblclean);
        
        String cleanOptions[]={"Clean","Dirty"};
        cleanCombo=new JComboBox(cleanOptions);
        cleanCombo.setBounds(200,180,150,30);
        cleanCombo.setBackground(Color.WHITE);
        add(cleanCombo);
        
        JLabel lblprice= new JLabel("Room Price");
        lblprice.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblprice.setBounds(60, 230, 120, 30);
        add(lblprice);
        
         tfprice = new JTextField();
        tfprice.setBounds(200, 230, 150, 30);
        add(tfprice);
        
        JLabel lblbedtype= new JLabel("Bed Type");
        lblbedtype.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblbedtype.setBounds(60, 280, 120, 30);
        add(lblbedtype);
        
        String typeOptions[]={"Single","Double"};
        typeCombo=new JComboBox(typeOptions);
        typeCombo.setBounds(200,280,150,30);
        typeCombo.setBackground(Color.WHITE);
        add(typeCombo);
        
       add= new JButton("Add Room");
                add.setBackground(Color.BLACK);
                 add.setForeground(Color.WHITE);
                  add.setBounds(60,350,130,30);
                add.addActionListener(this);

                    add(add);                    

cancel = new JButton("Cancel Room");
cancel.setBackground(Color.BLACK);
cancel.setForeground(Color.WHITE);
cancel.setBounds(220, 350, 130, 30); // Position of Cancel Room button (shifted right)
cancel.addActionListener(this);
add(cancel);


                    
                    ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/twelve.jpg"));
               
                  JLabel image = new JLabel(i1);
                   image.setBounds(400,30,500,300);
                    add(image);
        
         setBounds(330, 200, 940, 470);
        // Set frame visibility
        setVisible(true);
    }
    @Override
   public void actionPerformed(ActionEvent ae) {
      if( ae.getSource()==add){
           String room_number = tfroom.getText();
              String availability= (String)availableCombo.getSelectedItem();
                String clean_status= (String)cleanCombo.getSelectedItem();
                 String price= tfprice.getText();
                 String bed_type= (String)typeCombo.getSelectedItem();
                 
                 try{
                     Conn c=new Conn();
                  String str = "INSERT INTO room (room_number, availability, clean_status, price, bed_type) " + 
        "VALUES ('" + room_number + "', '" + availability + "', '" + clean_status + "', '" + price + "', '" + bed_type + "')";
                   
                   c.s.executeUpdate(str);
                   JOptionPane.showMessageDialog(null,"New room added sucessfully");
                   setVisible(false);

                 }
                 catch (SQLException e){
                     e.printStackTrace();
                 }
   }
      else{
          
          //setVisible(false);
      }
   }
    
    public static void main(String[]args){
        new AddRoom();
    }
}