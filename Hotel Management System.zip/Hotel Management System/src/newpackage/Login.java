/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
/**
 *
 * @author Maisam's PC
 */
public class Login extends JFrame implements ActionListener{
    JTextField username;
    JPasswordField password;
    JButton login,cancel;
    Login(){
        setBounds(200,200,600,300);
        getContentPane().setBackground(Color.white);
        setLayout(null);
        JLabel user=new JLabel("User name");
        user.setBounds(40,20,100,30);
        user.setFont(new Font("serif",Font.PLAIN,20));
        add(user);
        
        username=new JTextField();
        username.setBounds(150,20,150,30);
        add(username);
        
        JLabel pass=new JLabel("Password");
        pass.setBounds(40,60,100,30);
        pass.setFont(new Font("serif",Font.PLAIN,20));
        add(pass);
        password=new JPasswordField();
        password.setBounds(150,60,150,30);
        add(password);
        
        login=new JButton("Login");
         login.setBounds(40,140,120,30);
         login.setBackground(Color.black);
         login.setForeground(Color.white);
         login.addActionListener(this);
        add(login);
        cancel=new JButton("Cancel");
         cancel.setBounds(180,140,120,30);
         cancel.setBackground(Color.black);
         cancel.setForeground(Color.white);
         cancel.addActionListener(this);
        add(cancel);
        
        ImageIcon icon1=new ImageIcon(ClassLoader.getSystemResource("icons/second.jpg"));
        Image icon2=icon1.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
        icon1=new ImageIcon(icon2);
        JLabel image=new JLabel(icon1);
        image.setBounds(350,10,200,200);
        add(image);
        setVisible(true);
    }
    
   @Override
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==login){
            String user=username.getText();
            String pass=password.getText();
            
            try{
                Conn c=new Conn();
                 
                String query="select * from login where username = '"+user+"' and password = '"+pass+"' and role='admin'";
                String query2="select * from login where username = '"+user+"' and password = '"+pass+"' and role='user'";
                
                ResultSet rs=c.s.executeQuery(query);
                boolean check=true;
                if(rs.next()){
                   setVisible(false);
                   new Dashboard();
                  rs.close();
                  check=false;
                }
                else {
                    rs.close();
                 ResultSet rs2=c.s.executeQuery(query2);
                 if(rs2.next()){
                  setVisible(false);
                    new Booking();   
                    check=false;
                 }
                rs2.close();                   
                }
                if(check){
                    JOptionPane.showMessageDialog(null, "invalid username or password");
                    setVisible(false);
                }
                
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }else if(ae.getSource()==cancel){
            setVisible(false);
        }
    }
  
    
    public static void main(String[] args) {       
        new Login();
    }
}