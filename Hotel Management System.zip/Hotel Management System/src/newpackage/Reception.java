/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author Maisam's PC
 */
public class Reception extends JFrame implements ActionListener{
      JButton newCustomer,rooms,department, allEmployees,managerInfo,customer,searchRoom;
     JButton roomStatus,pickup, updateStatus,checkout,logOut;
        
    Reception(){
        getContentPane().setBackground(Color.WHITE);
        
        setLayout(null);
        newCustomer= new JButton("New Customer Form");
        newCustomer.setBounds(10,30,200,30);
        newCustomer.setBackground(Color.black);
        newCustomer.setForeground(Color.white);
        newCustomer.addActionListener(this);
        add(newCustomer);
        
        rooms= new JButton("Room");
        rooms.setBounds(10,70,200,30);
        rooms.setBackground(Color.black);
        rooms.setForeground(Color.white);
        rooms.addActionListener(this);
        add(rooms);
        
        department= new JButton("Department");
        department.setBounds(10,110,200,30);
        department.setBackground(Color.black);
        department.setForeground(Color.white);
        department.addActionListener(this);
        add(department);
        
        allEmployees= new JButton("All Employees");
        allEmployees.setBounds(10,150,200,30);
        allEmployees.setBackground(Color.black);
        allEmployees.setForeground(Color.white);
        allEmployees.addActionListener(this);
        add(allEmployees);
        
        customer= new JButton("Customer Information");
        customer.setBounds(10,190,200,30);
        customer.setBackground(Color.black);
        customer.setForeground(Color.white);
        customer.addActionListener(this);
        add(customer);
        
        managerInfo= new JButton("Manager Information");
        managerInfo.setBounds(10,230,200,30);
        managerInfo.setBackground(Color.black);
        managerInfo.setForeground(Color.white);
        managerInfo.addActionListener(this);
        add(managerInfo);
        
        checkout= new JButton("Checkout");
        checkout.setBounds(10,270,200,30);
        checkout.setBackground(Color.black);
        checkout.setForeground(Color.white);
        checkout.addActionListener(this);
        add(checkout);
        
        updateStatus= new JButton("Update Status");
        updateStatus.setBounds(10,310,200,30);
        updateStatus.setBackground(Color.black);
        updateStatus.setForeground(Color.white);
        updateStatus.addActionListener(this);
        add(updateStatus);
        
        roomStatus= new JButton("Update room Status");
        roomStatus.setBounds(10,350,200,30);
        roomStatus.setBackground(Color.black);
        roomStatus.setForeground(Color.white);
        roomStatus.addActionListener(this);
        add(roomStatus);
        
        pickup= new JButton("Pickup service");
        pickup.setBounds(10,390,200,30);
        pickup.setBackground(Color.black);
        pickup.setForeground(Color.white);
        pickup.addActionListener(this);
        add(pickup);
        
        searchRoom= new JButton("Search room");
        searchRoom.setBounds(10,430,200,30);
        searchRoom.setBackground(Color.black);
        searchRoom.addActionListener(this);
        searchRoom.setForeground(Color.white);
        add(searchRoom);
        
        logOut= new JButton("Logout");
        logOut.setBounds(10,470,200,30);
        logOut.setBackground(Color.black);
        logOut.setForeground(Color.white);
        logOut.addActionListener(this);
        add(logOut);
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/fourth.jpg"));
        JLabel image = new JLabel(i1);
        image.setBounds(250,30,500,470);
        add(image);
        setBounds(300,100,800,570);
        setVisible(true);
    }
      @Override
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==newCustomer){
            setVisible(false);
            new CustomerForm();
          }else if(ae.getSource()==rooms){
              setVisible(false);
              new Room();
          }else if(ae.getSource()==department){
              setVisible(false);
              new Department();
          }else if(ae.getSource()==allEmployees){
              setVisible(false);
              new EmployeeInfo();
          }else if(ae.getSource()==managerInfo){
              setVisible(false);
              new ManagerInfo();
          }else if(ae.getSource()==customer){
              setVisible(false);
              new CustomerInfo();
          }else if(ae.getSource()==searchRoom){
              setVisible(false);
              new SearchRoom();
          }else if(ae.getSource()==updateStatus){
             setVisible(false);
             new UpdateCheck();
          }else if(ae.getSource()==roomStatus){
              setVisible(false);
              new UpdateRoom();
          }else if(ae.getSource()==pickup){
              setVisible(false);
              new Pickup();
          }else if(ae.getSource()==checkout){
              setVisible(false);
              new Checkout();
          }else if(ae.getSource()==logOut){
              setVisible(false);              
          }
        
    }
    public static void main(String[] args) {
        new Reception();
    }
}