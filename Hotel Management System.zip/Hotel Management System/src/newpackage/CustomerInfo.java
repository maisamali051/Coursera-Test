/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.*;

/**
 *
 * @author Maisam's PC
 */
public class CustomerInfo extends JFrame implements ActionListener{
    JTable table;
    JButton back;
    CustomerInfo(){
        getContentPane().setBackground(Color.white);
        setLayout(null);
        
        JLabel l1=new JLabel("Registration ID");
        l1.setBounds(10,10,100,20);
        add(l1);
        
        JLabel l2=new JLabel("Number");
        l2.setBounds(130,10,100,20);
        add(l2);
        
        JLabel l3=new JLabel("Name");
        l3.setBounds(250,10,100,20);
        add(l3);
        
        JLabel l4=new JLabel("Gender");
        l4.setBounds(360,10,100,20);
        add(l4);
        
        JLabel l5=new JLabel("Country");
        l5.setBounds(470,10,100,20);
        add(l5);
        
        JLabel l=new JLabel("room type");
        l.setBounds(570,10,100,20);
        add(l);
        
         JLabel l6=new JLabel("Room number");
        l6.setBounds(680,10,100,20);
        add(l6);
        
         JLabel l7=new JLabel("Deposit");
        l7.setBounds(790,10,100,20);
        add(l7);
        
         JLabel l8=new JLabel("Checkin time");
        l8.setBounds(900,10,100,20);
        add(l8);
        table=new JTable();
        table.setBounds(0,40,1000,400);
        add(table);
        
        try{
            Conn c=new Conn();
           ResultSet rs=c.s.executeQuery("select id, number, name, gender, country, bed_type, room_number, checkin_time from customer inner join room on customer.room_no=room.room_number ");
           table.setModel(DbUtils.resultSetToTableModel(rs));
        }catch (SQLException e){
            
        }
        
        back=new JButton("back");
        back.setBackground(Color.black);
        back.setForeground(Color.white);
        back.addActionListener(this);
        back.setBounds(200,500,120,30);
        add(back);
        
        setBounds(200,85,1000,600);
        setVisible(true);
        
    }
    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new Reception();
    }
    public static void main(String[] args) {
        new CustomerInfo();
    }
}