/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import java.awt.*;
import javax.swing.*;
import java.awt. event.*;
import java.sql.*;

/**
 *
 * @author Maisam's PC
 */
public class AddEmployee extends JFrame implements ActionListener {

    JTextField tfname,tfage,tfsalary,tfphone,tfemail,tfcnic; 
     JRadioButton  rbmale,rbfemale;
     JButton submit;
      JComboBox cbjob;
    AddEmployee() {
        // Set layout to null for absolute positioning
        setLayout(null);

        // Name
        JLabel Lname = new JLabel("Name");
        Lname.setFont(new Font("Tahoma", Font.PLAIN, 18));
        Lname.setBounds(60, 30, 120, 30);
        add(Lname);

        // Name field
        tfname = new JTextField();
        tfname.setBounds(200, 30, 150, 30);
        add(tfname);

        // Age
        JLabel Lage = new JLabel("Age");
        Lage.setFont(new Font("Tahoma", Font.PLAIN, 18));
        Lage.setBounds(60, 80, 120, 30);
        add(Lage);

        // Age field
         tfage = new JTextField();
        tfage.setBounds(200, 80, 150, 30);
        add(tfage);

        // Gender
        JLabel gender = new JLabel("Gender");
        gender.setFont(new Font("Tahoma", Font.PLAIN, 18));
        gender.setBounds(60, 130, 120, 30);
        add(gender);

        // Male button
       rbmale = new JRadioButton("Male");
        rbmale.setBounds(200, 130, 70, 30);
         rbmale.setFont(new Font("Tahoma", Font.PLAIN, 13));
          rbmale.setBackground(Color.WHITE);
        add(rbmale);

        // Female button
         rbfemale = new JRadioButton("Female");
          rbfemale.setBounds(280, 130, 70, 30);
           rbfemale.setFont(new Font("Tahoma", Font.PLAIN, 13));
            rbfemale.setBackground(Color.WHITE);
          add(rbfemale);

        // Grouping the gender buttons
        ButtonGroup genderGroup = new ButtonGroup();
         genderGroup.add(rbmale);
          genderGroup.add(rbfemale);
         
        // Job
        JLabel job = new JLabel("Job");
        job.setFont(new Font("Tahoma", Font.PLAIN, 18));
        job.setBounds(60, 180, 120, 30);
        add(job);

        // Job combo box
        String[] str = {
            "NULL", "Front Desk Clerk", "Porter", "Housekeeping", "Kitchen Staff",
            "Room Service", "Chef", "Waiter/Waitress", "Manager", "Accountant"
        };
        cbjob = new JComboBox(str);
        cbjob.setBounds(200, 180, 150, 30);
        cbjob.setBackground(Color.WHITE);
        add(cbjob);

        // Salary
        JLabel Lsalary = new JLabel("Salary");
        Lsalary.setFont(new Font("Tahoma", Font.PLAIN, 18));
        Lsalary.setBounds(60, 230, 120, 30);
        add(Lsalary);

        // Salary field
         tfsalary = new JTextField();
        tfsalary.setBounds(200, 230, 150, 30);
        add(tfsalary);

        // Phone number
        JLabel Lphone = new JLabel("Phone Number");
        Lphone.setFont(new Font("Tahoma", Font.PLAIN, 18));
        Lphone.setBounds(60, 280, 120, 30);
        add(Lphone);

        // Phone field
        tfphone = new JTextField();
        tfphone.setBounds(200, 280, 150, 30);
        add(tfphone);

        // Email
        JLabel Lemail = new JLabel("Email");
        Lemail.setFont(new Font("Tahoma", Font.PLAIN, 18));
        Lemail.setBounds(60, 330, 120, 30);
        add(Lemail);

        // Email field
        tfemail = new JTextField();
        tfemail.setBounds(200, 330, 150, 30);
        add(tfemail);
        // CNIC
JLabel Lcnic = new JLabel("CNIC");
Lcnic.setFont(new Font("Tahoma", Font.PLAIN, 18)); // Corrected to Lcnic
Lcnic.setBounds(60, 380, 120, 30); // Set the position and size
add(Lcnic);

// CNIC Text Field
 tfcnic = new JTextField(); // Define the text field
tfcnic.setBounds(200, 380, 150, 30); // Set the position and size
add(tfcnic);

        
               submit = new JButton("Submit");
                submit.setBackground(Color.BLACK);
                 submit.setForeground(Color.WHITE);
                  submit.setBounds(200,430,150,30);
                   submit.addActionListener(this);
                    add(submit);
               
               ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/tenth.jpg"));
                Image i2 = i1.getImage().getScaledInstance(450, 450, Image.SCALE_DEFAULT);
                 ImageIcon i3 = new ImageIcon(i2);
                  JLabel image = new JLabel(i3);
                   image.setBounds(380,0,450,370);
                    add(image);
        // Set background color
        getContentPane().setBackground(Color.WHITE);
         setBounds(300, 150, 800, 540);

        // Set frame visibility
        setVisible(true);
    }

     @Override
    public void actionPerformed(ActionEvent ae) {
    String name=tfname.getText();
      String age=tfage.getText();
        String salary=tfsalary.getText();
          String phone=tfphone.getText();
            String email=tfemail.getText();
             String  Cnic =tfcnic.getText();
             
             if(name.equals("")){
                 JOptionPane.showMessageDialog(null,"Name shouldnot be empty");
                 return;
             }
             
             String gender=null;
             if(rbmale.isSelected()){
                 gender="male";
             } else if( rbfemale.isSelected()){
                 gender = "female";
             }
             
             String job= (String)cbjob.getSelectedItem();
            try {
    Conn conn = new Conn(); // Assuming 'Conn' is your database connection class
    String query = "INSERT INTO employee (name, age, gender, job, salary, phone, Cnic, email) "
                 + "VALUES ('" + name + "', '" + age + "', '" + gender + "', '" + job + "', '" 
                 + salary + "', '" + phone + "', '" + Cnic + "', '" + email + "')";
    conn.s.executeUpdate(query); // Execute the query
    JOptionPane.showMessageDialog(null,"Employee added sucessfully");
    setVisible(false);
   
} catch (Exception e) {
    e.printStackTrace();
}
    }
    public static void main(String[] args) {
        new AddEmployee();
    }
} 
